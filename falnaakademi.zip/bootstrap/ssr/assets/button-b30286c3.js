import { jsx } from "react/jsx-runtime";
import { Link } from "@inertiajs/react";
function ButtonSubmit(props) {
  return /* @__PURE__ */ jsx(
    "button",
    {
      type: "submit",
      className: props.bgcolor + " " + props.hover + " text-white rounded-md px-2 py-1",
      children: props.children
    }
  );
}
function ButtonLink(props) {
  return /* @__PURE__ */ jsx(
    Link,
    {
      method: "get",
      as: "button",
      href: props.link,
      className: props.bgcolor + " " + props.hover + " text-white rounded-md px-2 py-1",
      children: props.children
    }
  );
}
export {
  ButtonSubmit as B,
  ButtonLink as a
};

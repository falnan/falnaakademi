import { jsx, Fragment, jsxs } from "react/jsx-runtime";
import { a as ButtonLink } from "./button-b30286c3.js";
import { L as LayoutDashboard } from "./layoutDashboard-126aa0e7.js";
import { usePage, router } from "@inertiajs/react";
import Swal from "sweetalert2";
import "react";
function DataStudent({ student }) {
  const { flash } = usePage().props;
  {
    flash == "success" && Swal.fire({
      title: "Good job!",
      text: "You clicked the button!",
      icon: "success"
    });
  }
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsx(LayoutDashboard, { setActiveLink: "Student", children: /* @__PURE__ */ jsxs("div", { className: "m-5", children: [
    /* @__PURE__ */ jsx("div", { className: "flex gap-2", children: /* @__PURE__ */ jsx(
      ButtonLink,
      {
        bgcolor: "bg-green-500",
        hover: "hover:bg-green-400",
        link: "/student/add",
        children: "Input Student"
      }
    ) }),
    /* @__PURE__ */ jsx("div", { className: "overflow-x-auto w-full bg-red-300 shadow-md sm:rounded-lg mt-5", children: /* @__PURE__ */ jsxs("table", { className: "text-sm text-left text-gray-500 ", children: [
      /* @__PURE__ */ jsx("thead", { className: "text-xs text-white uppercase bg-blue-400", children: /* @__PURE__ */ jsxs("tr", { className: "text-center", children: [
        /* @__PURE__ */ jsx("th", { className: "px-1  border-black", children: "No" }),
        /* @__PURE__ */ jsx("th", { className: "px-1 ", children: "Username" }),
        /* @__PURE__ */ jsx("th", { className: "w-20 py-2 ", children: "Nama Lengkap" }),
        /* @__PURE__ */ jsx("th", { className: "px-1 ", children: "Koin" }),
        /* @__PURE__ */ jsx("th", { className: "w-20 ", children: "Sekolah" }),
        /* @__PURE__ */ jsx("th", { className: "px-1 ", children: "Kelas" }),
        /* @__PURE__ */ jsx("th", { className: "w-20 ", children: "T-T-L" }),
        /* @__PURE__ */ jsx("th", { className: "w-20 ", children: "Alamat" }),
        /* @__PURE__ */ jsx("th", { className: "px-1 ", children: "Whatsapp" }),
        /* @__PURE__ */ jsx("th", { className: "w-24 ", children: "Ruang Belajar" }),
        /* @__PURE__ */ jsx("th", { className: "w-20", children: "Kata Sandi" }),
        /* @__PURE__ */ jsx("th", { colSpan: 2, children: "Action" })
      ] }) }),
      /* @__PURE__ */ jsx("tbody", { children: student.map((i, index) => /* @__PURE__ */ jsxs(
        "tr",
        {
          className: index % 2 === 0 ? "text-center bg-white" : "text-center bg-blue-50",
          children: [
            /* @__PURE__ */ jsx("td", { children: index + 1 }),
            /* @__PURE__ */ jsx("td", { children: i.username }),
            /* @__PURE__ */ jsx("td", { children: i.name }),
            /* @__PURE__ */ jsx("td", { children: i.coin }),
            /* @__PURE__ */ jsx("td", { children: i.school }),
            /* @__PURE__ */ jsx("td", { children: i.grade }),
            /* @__PURE__ */ jsx("td", { children: i.ttl }),
            /* @__PURE__ */ jsx("td", { children: i.adress }),
            /* @__PURE__ */ jsx("td", { children: i.phone }),
            /* @__PURE__ */ jsx("td", { children: i.rooms.map(
              (a) => a.id + ", "
            ) }),
            /* @__PURE__ */ jsx("td", { children: i.users.confirmPassword }),
            /* @__PURE__ */ jsx("td", { className: "px-2", children: /* @__PURE__ */ jsx(
              "svg",
              {
                className: "cursor-pointer fill-green-500",
                height: "16",
                width: "16",
                viewBox: "0 0 512 512",
                children: /* @__PURE__ */ jsx("path", { d: "M471.6 21.7c-21.9-21.9-57.3-21.9-79.2 0L362.3 51.7l97.9 97.9 30.1-30.1c21.9-21.9 21.9-57.3 0-79.2L471.6 21.7zm-299.2 220c-6.1 6.1-10.8 13.6-13.5 21.9l-29.6 88.8c-2.9 8.6-.6 18.1 5.8 24.6s15.9 8.7 24.6 5.8l88.8-29.6c8.2-2.7 15.7-7.4 21.9-13.5L437.7 172.3 339.7 74.3 172.4 241.7zM96 64C43 64 0 107 0 160V416c0 53 43 96 96 96H352c53 0 96-43 96-96V320c0-17.7-14.3-32-32-32s-32 14.3-32 32v96c0 17.7-14.3 32-32 32H96c-17.7 0-32-14.3-32-32V160c0-17.7 14.3-32 32-32h96c17.7 0 32-14.3 32-32s-14.3-32-32-32H96z" })
              }
            ) }),
            /* @__PURE__ */ jsx("td", { className: "px-2", children: /* @__PURE__ */ jsx(
              "svg",
              {
                onClick: (e) => {
                  Swal.fire({
                    title: "Are you sure?",
                    text: "You won't be able to revert this!",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#3085d6",
                    cancelButtonColor: "#d33",
                    confirmButtonText: "Yes, delete it!"
                  }).then((result) => {
                    if (result.isConfirmed) {
                      e.preventDefault();
                      router.delete(
                        "/student/" + i.username
                      );
                    }
                  });
                },
                className: "cursor-pointer fill-red-500",
                height: "16",
                width: "14",
                viewBox: "0 0 448 512",
                children: /* @__PURE__ */ jsx("path", { d: "M135.2 17.7L128 32H32C14.3 32 0 46.3 0 64S14.3 96 32 96H416c17.7 0 32-14.3 32-32s-14.3-32-32-32H320l-7.2-14.3C307.4 6.8 296.3 0 284.2 0H163.8c-12.1 0-23.2 6.8-28.6 17.7zM416 128H32L53.2 467c1.6 25.3 22.6 45 47.9 45H346.9c25.3 0 46.3-19.7 47.9-45L416 128z" })
              }
            ) })
          ]
        },
        i.username
      )) })
    ] }) })
  ] }) }) });
}
export {
  DataStudent as default
};

import { jsxs, Fragment, jsx } from "react/jsx-runtime";
import { B as ButtonSubmit, a as ButtonLink } from "./button-b30286c3.js";
import { F as Form } from "./form-67e5fbc8.js";
import { b as InputArea } from "./input-a6d724ad.js";
import { N as Navbar } from "./navbar-a0ee3b4f.js";
import { usePage, router } from "@inertiajs/react";
import { useState } from "react";
import "jquery";
function ReportTeacher({ report, subject }) {
  const { auth } = usePage().props;
  const [checked, setChecked] = useState(report.students[0].username);
  const [values, setValues] = useState({
    subject_id: subject,
    teacher_id: auth.id,
    student_id: report.students[0].username,
    evaluation: ""
  });
  const [errors, setErrors] = useState({ evaluation: "" });
  const reportFilter = report.students.filter(
    (i) => i.username == values.student_id
  );
  function handleChange(e) {
    const key = e.target.id;
    const value = e.target.value;
    setValues((values2) => ({
      ...values2,
      [key]: value
    }));
  }
  function handleSubmit(e) {
    e.preventDefault();
    router.post("/rapor", values);
  }
  router.on("error", (errors2) => {
    setErrors(errors2.detail.errors);
  });
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Navbar, { bgcolor: "bg-cyan-500" }),
    /* @__PURE__ */ jsxs(Form, { title: "Input Rapor", onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxs("p", { className: "text-gray-500 text-base capitalize", children: [
        "Nama Murid: ",
        values.student_id
      ] }),
      /* @__PURE__ */ jsx(
        InputArea,
        {
          label: "Evaluasi",
          id: "evaluation",
          onChange: handleChange,
          value: values.evaluation,
          error: errors.evaluation
        }
      ),
      /* @__PURE__ */ jsxs("div", { className: "flex gap-2 mt-5", children: [
        /* @__PURE__ */ jsx(
          ButtonSubmit,
          {
            bgcolor: "bg-green-500",
            hover: "hover:bg-green-600",
            children: "Submit"
          }
        ),
        /* @__PURE__ */ jsx(
          ButtonLink,
          {
            hover: "hover:bg-orange-500",
            bgcolor: "bg-orange-400",
            link: "/dashboard",
            children: "Dashboard"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "grid grid-flow-col mt-5", children: report.students.map((i) => /* @__PURE__ */ jsx(
      "div",
      {
        className: checked === i.username ? "bg-cyan-500 rounded-t-xl text-center p-2 capitalize text-sm" : "bg-white text-center p-2 capitalize text-sm",
        onClick: (e) => {
          setChecked(i.username);
          setValues((v) => ({
            ...v,
            student_id: i.username
          }));
        },
        children: i.username
      },
      i.username
    )) }),
    /* @__PURE__ */ jsx("div", { className: "bg-cyan-500 py-4", children: /* @__PURE__ */ jsx("div", { className: "sm:w-[80%] sm:mx-auto overflow-x-auto shadow-md sm:rounded-lg m-5", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-sm text-left text-gray-500 ", children: [
      /* @__PURE__ */ jsx("thead", { className: "text-xs text-gray-700 uppercase bg-gray-200 ", children: /* @__PURE__ */ jsxs("tr", { className: "text-center", children: [
        /* @__PURE__ */ jsx("th", { className: "px-6 py-3 w-40", children: "Tanggal" }),
        /* @__PURE__ */ jsx("th", { scope: "col", className: "px-6 py-3", children: "Evaluasi" })
      ] }) }),
      reportFilter[0].reports.map((i, index) => /* @__PURE__ */ jsx("tbody", { children: /* @__PURE__ */ jsxs(
        "tr",
        {
          className: index % 2 === 0 ? "bg-white" : "bg-gray-100",
          children: [
            /* @__PURE__ */ jsx("td", { className: "text-center", children: new Date(i.created_at).getDate() + "-" + new Date(
              i.created_at
            ).toLocaleString([], {
              month: "short"
            }) + "-" + new Date(
              i.created_at
            ).getFullYear() }),
            /* @__PURE__ */ jsx("td", { children: i.evaluation })
          ]
        }
      ) }, index))
    ] }) }) })
  ] });
}
export {
  ReportTeacher as default
};

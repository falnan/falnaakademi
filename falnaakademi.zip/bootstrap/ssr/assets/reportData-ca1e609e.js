import { jsxs, Fragment, jsx } from "react/jsx-runtime";
import { N as Navbar } from "./navbar-a0ee3b4f.js";
import { usePage } from "@inertiajs/react";
import "jquery";
import "react";
function ReportData({ report, subject }) {
  const { studentAuth } = usePage().props;
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Navbar, { bgcolor: "bg-cyan-500" }),
    /* @__PURE__ */ jsxs("div", { className: "sm:w-[80%] sm:mx-auto m-5", children: [
      /* @__PURE__ */ jsx("table", { className: "capitalize text-gray-800 text-sm leading-5", children: /* @__PURE__ */ jsxs("tbody", { children: [
        /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("td", { children: "Nama" }),
          /* @__PURE__ */ jsx("td", { children: ":  " }),
          /* @__PURE__ */ jsx("td", { children: studentAuth.name })
        ] }),
        /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("td", { children: "Pelajaran" }),
          /* @__PURE__ */ jsx("td", { children: ": " }),
          /* @__PURE__ */ jsx("td", { children: subject.subject })
        ] })
      ] }) }),
      /* @__PURE__ */ jsx("div", { className: "relative overflow-x-auto shadow-md rounded-lg", children: /* @__PURE__ */ jsxs("table", { className: "table-auto w-full text-sm text-gray-500", children: [
        /* @__PURE__ */ jsx("thead", { className: "text-xs bg-blue-400 text-white uppercase", children: /* @__PURE__ */ jsxs("tr", { className: "text-center", children: [
          /* @__PURE__ */ jsx("th", { className: "px-6 py-3 w-40", children: "Tanggal" }),
          /* @__PURE__ */ jsx("th", { scope: "col", className: "px-6 py-3", children: "Evaluasi" })
        ] }) }),
        /* @__PURE__ */ jsx("tbody", { children: report.map((i, index) => /* @__PURE__ */ jsxs(
          "tr",
          {
            className: index % 2 === 0 ? "text-center bg-white" : "text-center bg-blue-100",
            children: [
              /* @__PURE__ */ jsx("td", { className: "px-6 py-3", children: "tanggal" }),
              /* @__PURE__ */ jsx("td", { className: "px-6 py-3 text-left", children: i.evaluation })
            ]
          },
          index
        )) })
      ] }) })
    ] })
  ] });
}
export {
  ReportData as default
};

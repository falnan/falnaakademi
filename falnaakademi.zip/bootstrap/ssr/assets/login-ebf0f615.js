import { jsxs, jsx } from "react/jsx-runtime";
import { B as ButtonSubmit } from "./button-b30286c3.js";
import { F as Form } from "./form-67e5fbc8.js";
import { I as InputText } from "./input-a6d724ad.js";
import { N as Navbar } from "./navbar-a0ee3b4f.js";
import { router, Link } from "@inertiajs/react";
import { useState } from "react";
import "jquery";
function Login() {
  const [values, setValues] = useState({
    username: "",
    name: "",
    password: ""
  });
  const [errors, setErrors] = useState("");
  function handleChange(e) {
    const key = e.target.id;
    const value = e.target.value;
    setValues((values2) => ({
      ...values2,
      [key]: value
    }));
  }
  function handleSubmit(e) {
    e.preventDefault();
    router.post("/login", values);
  }
  router.on("error", (error) => {
    setErrors(error.detail.errors);
  });
  return /* @__PURE__ */ jsxs("main", { children: [
    /* @__PURE__ */ jsx(Navbar, { bgcolor: "bg-cyan-500" }),
    errors.message == "try again" && /* @__PURE__ */ jsx("div", { className: "bg-red-500 text-white text-center", children: "Data Salah" }),
    /* @__PURE__ */ jsxs(Form, { onSubmit: handleSubmit, title: "Login", children: [
      /* @__PURE__ */ jsx(
        InputText,
        {
          label: "Username",
          id: "username",
          onChange: handleChange,
          value: values.username,
          error: errors.username
        }
      ),
      /* @__PURE__ */ jsx(
        InputText,
        {
          label: "Nama Lengkap",
          id: "name",
          onChange: handleChange,
          value: values.name,
          error: errors.name
        }
      ),
      /* @__PURE__ */ jsx(
        InputText,
        {
          label: "Kata Sandi",
          id: "password",
          onChange: handleChange,
          value: values.password,
          error: errors.password
        }
      ),
      /* @__PURE__ */ jsx("div", { className: "mt-2", children: /* @__PURE__ */ jsx(
        ButtonSubmit,
        {
          bgcolor: "bg-green-500",
          hover: "hover:bg-green-600",
          children: "Login"
        }
      ) }),
      /* @__PURE__ */ jsxs("p", { className: "text-sm", children: [
        "Belum mempunyai akun? Daftar",
        " ",
        /* @__PURE__ */ jsx("span", { children: /* @__PURE__ */ jsx(
          Link,
          {
            as: "button",
            className: "text-blue-500",
            href: "/daftar",
            children: "di sini"
          }
        ) })
      ] })
    ] })
  ] });
}
export {
  Login as default
};

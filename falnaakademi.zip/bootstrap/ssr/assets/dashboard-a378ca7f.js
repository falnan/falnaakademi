import { jsx } from "react/jsx-runtime";
import { usePage } from "@inertiajs/react";
import DashboardAdmin from "./dashboardAdmin-8d58c2ab.js";
import DashboardStudent from "./dashboardStudent-64b69d40.js";
import DashboardTeacher from "./dashboardTeacher-4d7284c7.js";
import "./layoutDashboard-126aa0e7.js";
import "react";
import "./button-b30286c3.js";
import "./navbar-a0ee3b4f.js";
import "jquery";
function Dashboard({ studentRoom, teacherRoom }) {
  const { auth } = usePage().props;
  if (auth.user.role == "admin") {
    return /* @__PURE__ */ jsx(DashboardAdmin, {});
  } else if (auth.user.role == "student") {
    return /* @__PURE__ */ jsx(DashboardStudent, { studentRoom });
  } else if (auth.user.role == "teacher") {
    return /* @__PURE__ */ jsx(DashboardTeacher, { teacherRoom });
  }
}
export {
  Dashboard as default
};

import { jsx, jsxs } from "react/jsx-runtime";
function Form(props) {
  return /* @__PURE__ */ jsx("div", { className: "bg-white shadow-lg border-2 mx-auto w-[85%] sm:w-80 mt-5 p-3 px-8 rounded-lg", children: /* @__PURE__ */ jsxs("form", { onSubmit: props.onSubmit, className: "flex flex-col gap-2", children: [
    /* @__PURE__ */ jsx("p", { className: "text-gray-500 font-bold text-center text-2xl", children: props.title }),
    props.children
  ] }) });
}
export {
  Form as F
};

import { jsxs, jsx } from "react/jsx-runtime";
import $ from "jquery";
import { N as Navbar } from "./navbar-a0ee3b4f.js";
import { Link } from "@inertiajs/react";
import "react";
const data = [
  {
    ask: "Bagaimana sistem belajar di Falna Akademi?",
    ket: "Pembelajaran dilakukan secara online dengan menggunakan aplikasi zoom yang akan diajarkan oleh tutor-tutor berpengalaman."
  },
  {
    ask: "Bagaimana sistem belajar di Falna Akademi?",
    ket: "Selain bisa belajar dengan tutor-tutor berpengalaman di bidangnya, siswa juga mendapatkan fasilitas 'Tanya Soal'. Dengan Fasilitas ini, tim kami akan membantu siswa untuk menjawab pertanyaan atau PR mereka."
  },
  {
    ask: "Bagaimana cara untuk menggunakan fitur 'Tanya Soal'?",
    ket: "Cukup mudah, Anda hanya perlu mengirimkan pertanyaan dalam bentuk tulisan atau gambar ke ke kolom yang sudah disediakan di menu 'Tanya Soal,' Anda bisa mengakases menu ini setelah mendaftar di Falna Akademi."
  },
  {
    ask: "Apakah Falna Akademi menyediakan layanan bimbel offline?",
    ket: "Kami menyediakan Bimbel Offline di beberapa wilayah di Indonesia, silahkan hubungi Admin untuk mengetahui apakah wilayah Anda juga termasuk salah satunya."
  },
  {
    ask: "Apakah tersedia pembelajaran dengan bahasa Asing?",
    ket: "Kami juga menyiadakan bimbel dengan menggunakan bahasa pengantar asing dengan biaya tambahan, untuk penjelasan lebih lanjut silahkan hubungi Admin Falna Akademi."
  }
];
function FAQ() {
  return /* @__PURE__ */ jsxs("div", { className: "bg-gradient-to-tr from-blue-400 via-cyan-500 to-cyan-500 w-full flex flex-col gap-2 py-5 mt-5", children: [
    /* @__PURE__ */ jsx("p", { className: "text-center text-white font-semibold text-2xl", children: "Sering Ditanyakan" }),
    data.map((i, index) => /* @__PURE__ */ jsx(
      "div",
      {
        className: "bg-white text-gray-700 w-[90%] rounded-md mx-auto",
        children: /* @__PURE__ */ jsxs("div", { className: "relative flex flex-col p-3", children: [
          /* @__PURE__ */ jsxs(
            "div",
            {
              onClick: () => $("#" + String(index)).slideToggle("fast"),
              className: "flex justify-between",
              children: [
                /* @__PURE__ */ jsx("p", { className: "font-semibold items-start", children: i.ask }),
                /* @__PURE__ */ jsx("i", { className: "fa-solid fa-caret-down" })
              ]
            }
          ),
          /* @__PURE__ */ jsx("p", { id: String(index), className: "jadi leading-5 hidden", children: i.ket })
        ] })
      },
      index
    ))
  ] });
}
const dataMedsos = [
  {
    media: "facebook",
    link: ""
  },
  {
    media: "whatsapp",
    link: ""
  },
  {
    media: "instagram",
    link: ""
  },
  {
    media: "telegram",
    link: ""
  }
];
const dataMenu = [
  {
    link: "/bimbelreguler",
    ket: "Bimbel Reguler"
  },
  {
    link: "/bimbelprivat",
    ket: "Bimbel Privat"
  },
  {
    link: "/englishcourse",
    ket: "English Course"
  },
  {
    link: "/falnakids",
    ket: "Falna Kids"
  }
];
function Footer() {
  const medsos = dataMedsos.map((i) => /* @__PURE__ */ jsx("div", { className: "", children: /* @__PURE__ */ jsxs("a", { className: "flex flex-row", href: i.link, children: [
    /* @__PURE__ */ jsx("i", { className: "fa-brands fa-" + i.media + " text-xl" }),
    /* @__PURE__ */ jsx("p", { className: "self-center ml-2", children: i.media })
  ] }) }, i.media));
  const menu = dataMenu.map((i, index) => /* @__PURE__ */ jsxs("div", { className: "flex flex-row", children: [
    /* @__PURE__ */ jsx("i", { className: "fa-solid fa-caret-right self-center" }),
    /* @__PURE__ */ jsx("a", { href: i.link, children: /* @__PURE__ */ jsx("p", { className: "ml-2", children: i.ket }) })
  ] }, index));
  return /* @__PURE__ */ jsxs("div", { className: "bg-cyan-800 grid grid-flow-row md:grid-cols-3 p-5 text-white gap-5", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex flex-row my-3", children: [
        /* @__PURE__ */ jsx(
          "img",
          {
            src: "/img/logofalnaputih.svg",
            alt: "",
            className: "w-10 -mt-1"
          }
        ),
        /* @__PURE__ */ jsx("p", { className: "font-bold text-2xl", children: "Falna Akademi" })
      ] }),
      /* @__PURE__ */ jsx("p", { children: "Bimbel Online untuk Generasi Emas Indonesia." }),
      /* @__PURE__ */ jsx("div", { className: "flex flex-col", children: medsos })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col", children: [
      /* @__PURE__ */ jsx("p", { className: "font-bold text-2xl my-3", children: "Paket Belajar" }),
      menu
    ] }),
    /* @__PURE__ */ jsx("div", { className: "flex flex-col", children: /* @__PURE__ */ jsx("p", { className: "font-bold text-2xl my-3", children: "Hubungi" }) }),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-row border-t md:col-span-3 items-center justify-center", children: [
      /* @__PURE__ */ jsx("i", { className: "fa-solid fa-copyright mt-10 mb-4" }),
      /* @__PURE__ */ jsx("p", { className: "mt-10 mb-4 ml-1", children: "Lentera Akademi. All right reserved" })
    ] })
  ] });
}
function Home() {
  const data1 = [
    {
      img: "wifi.svg",
      ket: "Bimbel Online",
      link: "bimbelreguler"
    },
    {
      img: "chat.svg",
      ket: "English Course",
      link: "englishcourse"
    },
    {
      img: "kids.svg",
      ket: "Falna Kids",
      link: "falnakids"
    }
  ];
  const data2 = [
    {
      img: "ngajiquran.svg",
      ket: "Ngaji Quran",
      link: "ngajiquran"
    },
    {
      img: "it.svg",
      ket: "Ngerti IT",
      link: "ngertiit"
    }
  ];
  const data3 = [
    {
      judul: "Matematika",
      from: "from-red-300",
      to: "to-red-300",
      color: "bg-red-400",
      servedby: "logoreguler.svg",
      img: "math.svg",
      imgclass: "right-2 -bottom-10 w-48",
      durasi: "60",
      ketbtnatas: "2"
    },
    {
      judul: "English",
      from: "from-blue-300",
      to: "to-blue-300",
      color: "bg-blue-400",
      servedby: "logoenglish.svg",
      img: "phone2.svg",
      imgclass: "right-2 -bottom-2 w-36",
      durasi: "60",
      ketbtnatas: "2"
    },
    {
      judul: "Belajar Membaca",
      from: "from-orange-300",
      to: "to-orange-300",
      color: "bg-orange-400",
      servedby: "logokids.svg",
      img: "dinoabc.svg",
      imgclass: "right-0 bottom-6 w-44",
      durasi: "35",
      ketbtnatas: "4"
    },
    {
      judul: "Ngaji",
      from: "from-green-300",
      to: "to-green-300",
      color: "bg-red-400",
      servedby: "logongajiquran.svg",
      img: "quran.svg",
      imgclass: "right-0 -bottom-3 w-56",
      durasi: "35",
      ketbtnatas: "4"
    }
  ];
  return /* @__PURE__ */ jsxs("main", { className: "bg-slate-100", children: [
    /* @__PURE__ */ jsx(Navbar, { bgcolor: "bg-cyan-500" }),
    /* @__PURE__ */ jsxs("div", { className: "bg-gradient-to-tr from-blue-500 via-cyan-500 to-cyan-500 relative h-64 md:h-96 bg-cyan-600 overflow-hidden", children: [
      /* @__PURE__ */ jsxs("div", { className: "text-white m-5 w-40 md:w-72 md:m-12 md:ml-16", children: [
        /* @__PURE__ */ jsx("p", { className: "text-4xl md:text-5xl font-bold", children: "Falna Akademi" }),
        /* @__PURE__ */ jsx("p", { className: "md:text-3xl md:mt-0 max-md:leading-5", children: "Bimbel Online dan Offline pilihan juara." }),
        /* @__PURE__ */ jsx("button", { className: " bg-orange-400 shadow-md mt-2 md:text-lg px-2 py-1 text-white rounded-md md:px-5 md:py-2", children: /* @__PURE__ */ jsx(Link, { href: "/daftar", children: "Daftar" }) })
      ] }),
      /* @__PURE__ */ jsx(
        "img",
        {
          src: "/img/o.svg",
          alt: "",
          className: "absolute -top-20 -right-10 w-60 md:w-96"
        }
      ),
      /* @__PURE__ */ jsx(
        "img",
        {
          src: "/img/o.svg",
          alt: "",
          className: "max-md:hidden absolute -bottom-40 right-60 w-96"
        }
      ),
      /* @__PURE__ */ jsx(
        "img",
        {
          src: "/img/online3.svg",
          alt: "",
          className: "absolute right-0 bottom-12 w-48 md:bottom-10 md:right-20 md:w-96"
        }
      )
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "relative -top-16 w-[90%] h-40 md:h-28 rounded-2xl bg-white shadow-md mx-auto", children: [
      /* @__PURE__ */ jsx("p", { className: "md:hidden text-center p-3 text-lg text-gray-600  font-semibold", children: "Pilihan Paket Belajar" }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-row justify-around text-center md:text-left md:p-4 ", children: [
        data1.map((i) => /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsxs(
          Link,
          {
            href: i.link,
            className: "flex flex-col md:flex-row w-20 items-center md:border-2  border-gray-300 md:p-2 rounded-xl md:w-44",
            children: [
              /* @__PURE__ */ jsx(
                "img",
                {
                  src: "img/" + i.img,
                  alt: "",
                  className: "w-14"
                }
              ),
              /* @__PURE__ */ jsx("p", { className: "leading-5 text-gray-700 md:text-md md:ml-2 md:leading-6", children: i.ket })
            ]
          }
        ) }, i.link)),
        data2.map((i) => /* @__PURE__ */ jsx(
          "div",
          {
            className: "hidden xl:flex xl:flex-row w-20 items-center border-2 border-gray-300 xl:p-2 rounded-xl xl:w-44",
            children: /* @__PURE__ */ jsxs(
              Link,
              {
                href: i.link,
                className: "flex flex-row items-center",
                children: [
                  /* @__PURE__ */ jsx(
                    "img",
                    {
                      src: "img/" + i.img,
                      alt: "",
                      className: "w-14"
                    }
                  ),
                  /* @__PURE__ */ jsx("p", { className: "leading-5 text-gray-700 md:text-md md:ml-2 md:leading-6", children: i.ket })
                ]
              }
            )
          },
          i.link
        )),
        /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsxs(
          Link,
          {
            href: "/konsultasi",
            className: "flex flex-col md:flex-row w-20 items-center md:border-2 border-gray-300 md:p-2 rounded-xl md:w-44",
            children: [
              /* @__PURE__ */ jsx(
                "img",
                {
                  src: "/img/lainnya.svg",
                  alt: "",
                  width: 1,
                  height: 1,
                  className: "w-14"
                }
              ),
              /* @__PURE__ */ jsx("p", { className: "leading-5 text-gray-700 md:text-md md:ml-2 md:leading-6", children: "Paket Lainnya" })
            ]
          }
        ) })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "relative flex flex-row -top-10 ml-8 md:ml-16", children: [
      /* @__PURE__ */ jsx("img", { src: "/img/stars.svg", alt: "", className: "w-12" }),
      /* @__PURE__ */ jsx("p", { className: "self-center ml-2 text-xl font-semibold text-gray-600", children: "Paket Belajar Populer" })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "relative -top-5 overflow-x-auto", children: /* @__PURE__ */ jsxs("div", { className: "inline-flex ml-2 md:ml-12", children: [
      data3.map((i) => /* @__PURE__ */ jsxs("div", { className: "w-56 ml-5 ", children: [
        /* @__PURE__ */ jsxs(
          "div",
          {
            className: "relative overflow-hidden h-60 mx-auto w-56 rounded-t-xl bg-gradient-to-bl " + i.from + " " + i.to,
            children: [
              /* @__PURE__ */ jsx(
                "img",
                {
                  src: "img/o.svg",
                  alt: "",
                  className: "absolute w-60 -left-10 -top-10"
                }
              ),
              /* @__PURE__ */ jsx("div", { className: "absolute left-3 top-3 bg-blue-700 inline px-3 rounded-full  text-white", children: i.judul }),
              /* @__PURE__ */ jsx("p", { className: "pt-9 pl-4 text-gray-700", children: "Served by" }),
              /* @__PURE__ */ jsx(
                "img",
                {
                  src: "/img/" + i.servedby,
                  alt: "",
                  className: "w-40 pl-4 -mt-1"
                }
              ),
              /* @__PURE__ */ jsx(
                "img",
                {
                  src: "/img/" + i.img,
                  alt: "",
                  className: "absolute " + i.imgclass
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ jsxs("div", { className: "relative h-80 bg-white rounded-xl -top-5 shadow-md", children: [
          /* @__PURE__ */ jsxs("div", { className: "container ml-4 pt-2", children: [
            /* @__PURE__ */ jsx("button", { className: "flex ml-14 mt-2 justify-between w-20 bg-green-500 px-5 py-1 rounded-md text-white font-semibold", children: /* @__PURE__ */ jsx(Link, { href: "/daftar", children: "Daftar" }) }),
            /* @__PURE__ */ jsx("p", { className: "font-semibold text-lg text-gray-700", children: "Fasilitas:" }),
            /* @__PURE__ */ jsxs("div", { className: "flex", children: [
              /* @__PURE__ */ jsx(
                "img",
                {
                  src: "/img/check1.svg",
                  alt: "",
                  width: 1,
                  height: 1,
                  className: "w-4"
                }
              ),
              /* @__PURE__ */ jsx("p", { className: "ml-1", children: " Online Grup " })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex", children: [
              /* @__PURE__ */ jsx(
                "img",
                {
                  src: "img/check1.svg",
                  alt: "",
                  width: 1,
                  height: 1,
                  className: "w-4"
                }
              ),
              /* @__PURE__ */ jsx("p", { className: "ml-1", children: "Max 6 orang / kelas" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex", children: [
              /* @__PURE__ */ jsx(
                "img",
                {
                  src: "img/check1.svg",
                  alt: "",
                  width: 1,
                  height: 1,
                  className: "w-4"
                }
              ),
              /* @__PURE__ */ jsx("p", { className: "ml-1", children: "Layanan tanya soal" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex", children: [
              /* @__PURE__ */ jsx(
                "img",
                {
                  src: "img/check1.svg",
                  alt: "",
                  width: 1,
                  height: 1,
                  className: "w-4"
                }
              ),
              /* @__PURE__ */ jsx("p", { className: "ml-1", children: i.durasi + " menit / sesi" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex", children: [
              /* @__PURE__ */ jsx(
                "img",
                {
                  src: "img/check1.svg",
                  alt: "",
                  width: 1,
                  height: 1,
                  className: "w-4"
                }
              ),
              /* @__PURE__ */ jsx("p", { className: "ml-1", children: "Laporan belajar" })
            ] })
          ] }),
          /* @__PURE__ */ jsx("p", { className: "font-semibold ml-4 mt-3 text-lg text-gray-700", children: "Biaya per Bulan:" }),
          /* @__PURE__ */ jsxs(
            "div",
            {
              className: "flex mt-1 justify-between w-[85%] mx-auto " + i.color + " px-4 rounded-full text-white",
              children: [
                /* @__PURE__ */ jsx("span", { className: "self-center text-sm", children: i.ketbtnatas + " sesi / minggu" }),
                /* @__PURE__ */ jsx("span", { className: "font-bold text-lg", children: "140K" })
              ]
            }
          )
        ] })
      ] }, i.judul)),
      /* @__PURE__ */ jsx("div", { className: "w-56 ml-5 ", children: /* @__PURE__ */ jsxs("div", { className: "relative overflow-hidden h-[540px] mx-auto w-56 rounded-xl bg-gradient-to-bl from-purple-300 to-purple-200 shadow-md", children: [
        /* @__PURE__ */ jsx(
          "img",
          {
            src: "img/o.svg",
            alt: "",
            width: 1,
            height: 1,
            className: "absolute w-60 -left-10 -top-10"
          }
        ),
        /* @__PURE__ */ jsx(
          "img",
          {
            src: "img/o.svg",
            alt: "",
            width: 1,
            height: 1,
            className: "absolute w-60 -right-10 top-20"
          }
        ),
        /* @__PURE__ */ jsx("p", { className: "leading-6 mt-10 ml-3 font-bold text-xl text-orange-500", children: "Lihat Semua Paket Belajar" }),
        /* @__PURE__ */ jsx(Link, { href: "/konsultasi", children: /* @__PURE__ */ jsx(
          "img",
          {
            src: "img/next.svg",
            alt: "",
            className: "relative w-10 ml-3"
          }
        ) }),
        /* @__PURE__ */ jsx(
          "img",
          {
            src: "img/phone.svg",
            alt: "",
            width: 1,
            height: 1,
            className: "absolute bottom-10"
          }
        )
      ] }) })
    ] }) }),
    /* @__PURE__ */ jsx(FAQ, {}),
    /* @__PURE__ */ jsx(Footer, {})
  ] });
}
export {
  Home as default
};

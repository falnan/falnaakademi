import { jsxs, Fragment, jsx } from "react/jsx-runtime";
import { usePage, router } from "@inertiajs/react";
import { useState } from "react";
const menu = [
  {
    name: "Dashboard",
    img: "fa-solid fa-house",
    link: "/dashboard",
    children: ""
  },
  {
    name: "Student",
    img: "fa-solid fa-user",
    link: "/student",
    children: ""
  },
  {
    name: "Teacher",
    img: "fa-solid fa-user-graduate",
    link: "/teacher",
    children: ""
  },
  {
    name: "Room",
    img: "fa-solid fa-chalkboard-user",
    link: "/room",
    children: ""
  }
];
function LayoutDashboard(props) {
  const { auth } = usePage().props;
  const [activeLink, setActiveLink] = useState(props.setActiveLink);
  const [fullSidebar, setFullSidebar] = useState(
    localStorage.getItem("sidebar")
  );
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs("div", { className: "flex justify-between h-20 sticky top-0 w-full bg-cyan-500 shadow-md", children: [
      /* @__PURE__ */ jsx("div", { className: "flex items-center justify-center h-full w-60", children: /* @__PURE__ */ jsx(
        "img",
        {
          className: "w-12",
          src: "/img/logofalnaputih.svg",
          alt: ""
        }
      ) }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center justify-center h-full w-60 text-white", children: [
        /* @__PURE__ */ jsx("p", { children: "Hai" }),
        /* @__PURE__ */ jsx("p", { children: auth.id })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-5", children: [
      /* @__PURE__ */ jsx(
        "div",
        {
          className: !fullSidebar ? "min-h-screen text-gray-700 transition-all duration-300 max-md:hidden" : "flex-none min-h-screen transition-all duration-300 text-gray-700 w-20 max-md:hidden",
          children: /* @__PURE__ */ jsx(
            "div",
            {
              className: !fullSidebar ? "fixed min-h-screen transition-all duration-300 w-60" : "fixed transition-all duration-300 w-20",
              children: /* @__PURE__ */ jsxs("div", { className: "p-4 ", children: [
                /* @__PURE__ */ jsx("div", {}),
                /* @__PURE__ */ jsx("div", { className: "ml-3 border-b-2 border-gray-300 text-gray-500 ", children: "Menu" }),
                menu.map((i) => /* @__PURE__ */ jsx(
                  "div",
                  {
                    onClick: () => {
                      router.get(i.link);
                    },
                    className: "flex flex-col p-1 cursor-pointer",
                    children: /* @__PURE__ */ jsxs(
                      "div",
                      {
                        className: activeLink == i.name ? "flex h-8 px-2.5 gap-3 items-center rounded-full bg-gradient-to-tr from-blue-400 to-cyan-500 text-white font-semibold" : "flex h-8 px-2.5 gap-3 items-center text-gray-700",
                        children: [
                          /* @__PURE__ */ jsx(
                            "i",
                            {
                              className: activeLink == i.name ? i.img + " text-white" : i.img + " text-cyan-500"
                            }
                          ),
                          !fullSidebar && /* @__PURE__ */ jsx("p", { children: i.name })
                        ]
                      }
                    )
                  },
                  i.name
                ))
              ] })
            }
          )
        }
      ),
      /* @__PURE__ */ jsx("div", { className: "col-span-4 bg-gray-100 min-h-screen text-black", children: props.children })
    ] })
  ] });
}
export {
  LayoutDashboard as L
};

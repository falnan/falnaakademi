import { jsxs, jsx } from "react/jsx-runtime";
import { a as ButtonLink } from "./button-b30286c3.js";
import { N as Navbar } from "./navbar-a0ee3b4f.js";
import { usePage, Link } from "@inertiajs/react";
import "jquery";
import "react";
function DashboardStudent({ studentRoom }) {
  const { studentAuth } = usePage().props;
  const color = ["bg-purple-200", "bg-orange-200", "bg-blue-200"];
  return /* @__PURE__ */ jsxs("div", { children: [
    /* @__PURE__ */ jsx(Navbar, { bgcolor: "bg-cyan-500" }),
    /* @__PURE__ */ jsxs("div", { className: "w-[90%] mx-auto", children: [
      /* @__PURE__ */ jsxs("div", { className: "relative md:w-96 shadow-lg bg-gradient-to-tr from-blue-400 via-cyan-500 to-cyan-500 rounded-lg  mt-5 p-3", children: [
        /* @__PURE__ */ jsx(
          "img",
          {
            src: "/img/piala.svg",
            className: "absolute right-0 top-2 w-28",
            alt: ""
          }
        ),
        /* @__PURE__ */ jsxs("p", { className: "text-yellow-300 text-2xl font-bold", children: [
          "Hello,",
          " ",
          /* @__PURE__ */ jsx("span", { className: "capitalize", children: studentAuth.username })
        ] }),
        /* @__PURE__ */ jsx("table", { className: "text-white", children: /* @__PURE__ */ jsxs("tbody", { children: [
          /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx("td", { children: "Nama" }),
            /* @__PURE__ */ jsxs("td", { children: [
              ": ",
              studentAuth.name
            ] })
          ] }),
          /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx("td", { children: "Sekolah" }),
            /* @__PURE__ */ jsxs("td", { children: [
              ": ",
              studentAuth.adress
            ] })
          ] }),
          /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx("td", { children: "Whatsapp" }),
            /* @__PURE__ */ jsxs("td", { children: [
              ": ",
              studentAuth.phone
            ] })
          ] }),
          /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx("td", { children: "Koin" }),
            /* @__PURE__ */ jsxs("td", { children: [
              ": ",
              studentAuth.coin
            ] })
          ] })
        ] }) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex gap-2 mt-4", children: [
        /* @__PURE__ */ jsx(
          ButtonLink,
          {
            link: "/koin",
            bgcolor: "bg-orange-400",
            hover: "hover:bg-orange-500",
            children: "Tambah Koin"
          }
        ),
        /* @__PURE__ */ jsxs(
          ButtonLink,
          {
            link: "/tanyasoal",
            bgcolor: "bg-blue-400",
            hover: "hover:bg-blue-500",
            children: [
              "Tanya Soal",
              " "
            ]
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxs("div", { className: "ml-5 sm:ml-10 md:ml-16 inline-flex gap-4", children: [
      studentRoom.map((i, index) => /* @__PURE__ */ jsxs(
        "div",
        {
          className: color[index] + " shadow-lg rounded-lg w-60  mt-5 p-3",
          children: [
            /* @__PURE__ */ jsxs("p", { className: "text-yellow-900 text-xl font-bold text-center", children: [
              "Paket Belajar ",
              index + 1
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "", children: [
              /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-3", children: [
                /* @__PURE__ */ jsx("p", { children: "Status" }),
                /* @__PURE__ */ jsxs("p", { className: "capitalize col-span-2", children: [
                  ":",
                  " ",
                  i.is_active == true ? "Aktif" : "Non-Aktif"
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-3", children: [
                /* @__PURE__ */ jsx("p", { children: "Pelajaran" }),
                /* @__PURE__ */ jsxs("p", { className: "capitalize col-span-2", children: [
                  ": ",
                  i.rooms.subjects.subject
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-3", children: [
                /* @__PURE__ */ jsx("p", { children: "Guru" }),
                /* @__PURE__ */ jsxs("p", { className: "capitalize col-span-2", children: [
                  ": ",
                  i.rooms.teachers.name
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-3", children: [
                /* @__PURE__ */ jsx("p", { children: "Program" }),
                /* @__PURE__ */ jsxs("p", { className: "capitalize col-span-2", children: [
                  ": Online ",
                  i.rooms.program
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-3", children: [
                /* @__PURE__ */ jsx("p", { children: "Hari" }),
                /* @__PURE__ */ jsxs("p", { className: "capitalize col-span-2", children: [
                  ": ",
                  i.rooms.day
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-3", children: [
                /* @__PURE__ */ jsx("p", { children: "Pukul" }),
                /* @__PURE__ */ jsxs("p", { className: "capitalize col-span-2", children: [
                  ": ",
                  i.rooms.time
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-3", children: [
                /* @__PURE__ */ jsx("p", { children: "ID Kelas" }),
                /* @__PURE__ */ jsxs("p", { className: "capitalize col-span-2", children: [
                  ":",
                  i.is_active == true ? i.rooms.idRoom : " ---"
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-3", children: [
                /* @__PURE__ */ jsx("p", { children: "Password" }),
                /* @__PURE__ */ jsxs("p", { className: "capitalize col-span-2", children: [
                  ":",
                  i.is_active == true ? i.passwordRoom : " ---"
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
              i.is_active == true ? /* @__PURE__ */ jsx(
                ButtonLink,
                {
                  link: i.linkRoom,
                  bgcolor: "bg-green-500",
                  hover: "hover:bg-green-600",
                  children: "Mulai Kelas"
                }
              ) : /* @__PURE__ */ jsx(
                "button",
                {
                  className: "bg-gray-500 px-3 py-1 text-white rounded-md line-through",
                  disabled: true,
                  children: "Mulai Kelas"
                }
              ),
              /* @__PURE__ */ jsx(
                ButtonLink,
                {
                  link: "rapor/data/" + i.rooms.subject_id,
                  bgcolor: "bg-blue-500",
                  hover: "hover:bg-blue-600",
                  children: "Rapor"
                }
              )
            ] })
          ]
        },
        i.id
      )),
      /* @__PURE__ */ jsx("div", { className: "shadow-lg bg-gray-200 rounded-lg w-60 mt-5 p-3", children: /* @__PURE__ */ jsxs(Link, { href: "/paketbelajar", children: [
        /* @__PURE__ */ jsx("i", { className: "w-full mt-14 text-center opacity-30 text-5xl fa-solid fa-circle-plus" }),
        /* @__PURE__ */ jsxs("div", { className: "mt-2 text-center text-xl font-bold text-gray-500", children: [
          /* @__PURE__ */ jsx("p", { children: "Tambah Paket" }),
          /* @__PURE__ */ jsx("p", { children: "Belajar" })
        ] })
      ] }) })
    ] }) })
  ] });
}
export {
  DashboardStudent as default
};

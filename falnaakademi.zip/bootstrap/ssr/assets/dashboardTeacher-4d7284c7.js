import { jsxs, jsx } from "react/jsx-runtime";
import { a as ButtonLink } from "./button-b30286c3.js";
import { N as Navbar } from "./navbar-a0ee3b4f.js";
import { usePage } from "@inertiajs/react";
import "jquery";
import "react";
function DashboardTeacher({ teacherRoom }) {
  const { teacherAuth } = usePage().props;
  const color = ["bg-purple-200", "bg-orange-200", "bg-blue-200"];
  return /* @__PURE__ */ jsxs("main", { children: [
    /* @__PURE__ */ jsx(Navbar, { bgcolor: "bg-cyan-500" }),
    /* @__PURE__ */ jsx("div", { className: "w-[90%] mx-auto", children: /* @__PURE__ */ jsxs("div", { className: "relative md:w-96 shadow-lg bg-gradient-to-tr from-blue-400 via-cyan-500 to-cyan-500 rounded-lg  mt-5 p-3", children: [
      /* @__PURE__ */ jsx(
        "img",
        {
          src: "/img/piala.svg",
          className: "absolute right-0 top-2 w-28",
          alt: ""
        }
      ),
      /* @__PURE__ */ jsxs("p", { className: "text-yellow-300 text-2xl font-bold", children: [
        "Hello,",
        " ",
        /* @__PURE__ */ jsx("span", { className: "capitalize", children: teacherAuth.username })
      ] }),
      /* @__PURE__ */ jsx("table", { className: "text-white", children: /* @__PURE__ */ jsxs("tbody", { children: [
        /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("td", { children: "Nama" }),
          /* @__PURE__ */ jsx("td", { children: ": " }),
          /* @__PURE__ */ jsx("td", { className: "capitalize", children: teacherAuth.name })
        ] }),
        /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("td", { children: "Whatsapp" }),
          /* @__PURE__ */ jsx("td", { children: ": " }),
          /* @__PURE__ */ jsx("td", { children: teacherAuth.phone })
        ] }),
        /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("td", { children: "Alamat" }),
          /* @__PURE__ */ jsx("td", { children: ": " }),
          /* @__PURE__ */ jsx("td", { children: teacherAuth.adress })
        ] })
      ] }) })
    ] }) }),
    /* @__PURE__ */ jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxs("div", { className: "ml-5 sm:ml-10 md:ml-16 inline-flex gap-4", children: [
      teacherRoom.map((i, index) => /* @__PURE__ */ jsxs(
        "div",
        {
          className: color[index] + " shadow-lg rounded-lg w-60  mt-5 p-3",
          children: [
            /* @__PURE__ */ jsxs("p", { className: "text-yellow-900 text-xl font-bold text-center", children: [
              "Paket Belajar ",
              index + 1
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "", children: [
              /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-3", children: [
                /* @__PURE__ */ jsx("p", { children: "Pelajaran" }),
                /* @__PURE__ */ jsxs("p", { className: "capitalize col-span-2", children: [
                  ": ",
                  i.subjects.subject
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-3", children: [
                /* @__PURE__ */ jsx("p", { children: "Grup" }),
                /* @__PURE__ */ jsxs("p", { className: "capitalize col-span-2", children: [
                  ": ",
                  i.program
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-3", children: [
                /* @__PURE__ */ jsx("p", { children: "Hari" }),
                /* @__PURE__ */ jsxs("p", { className: "capitalize col-span-2", children: [
                  ": ",
                  i.day
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-3", children: [
                /* @__PURE__ */ jsx("p", { children: "Pukul" }),
                /* @__PURE__ */ jsxs("p", { className: "capitalize col-span-2", children: [
                  ": ",
                  i.time
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-3", children: [
                /* @__PURE__ */ jsx("p", { children: "ID Kelas" }),
                /* @__PURE__ */ jsxs("p", { className: "capitalize col-span-2", children: [
                  ": ",
                  i.idRoom
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-3", children: [
                /* @__PURE__ */ jsx("p", { children: "Password" }),
                /* @__PURE__ */ jsxs("p", { className: "capitalize col-span-2", children: [
                  ": ",
                  i.passwordRoom
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
              /* @__PURE__ */ jsx(
                ButtonLink,
                {
                  link: i.linkRoom,
                  bgcolor: "bg-green-500",
                  hover: "hover:bg-green-600",
                  children: "Mulai Kelas"
                }
              ),
              /* @__PURE__ */ jsx(
                ButtonLink,
                {
                  link: "/rapor/" + i.id,
                  bgcolor: "bg-blue-500",
                  hover: "hover:bg-blue-600",
                  children: "Rapor"
                }
              )
            ] })
          ]
        },
        i.id
      )),
      /* @__PURE__ */ jsx("div", { className: "shadow-lg bg-gray-200 rounded-lg w-60 mt-5 p-3", children: /* @__PURE__ */ jsxs("div", { className: "text-center", children: [
        /* @__PURE__ */ jsx("i", { className: "w-full mt-14 opacity-30 text-5xl fa-solid fa-circle-plus" }),
        /* @__PURE__ */ jsx("div", { className: "mt-2 text-xl font-bold text-gray-500", children: /* @__PURE__ */ jsx("p", { children: "Paket Belajar Selanjutnya" }) })
      ] }) })
    ] }) })
  ] });
}
export {
  DashboardTeacher as default
};

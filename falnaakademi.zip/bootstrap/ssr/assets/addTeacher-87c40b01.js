import { jsx, Fragment, jsxs } from "react/jsx-runtime";
import { B as ButtonSubmit } from "./button-b30286c3.js";
import { F as Form } from "./form-67e5fbc8.js";
import { I as InputText, a as InputSelect } from "./input-a6d724ad.js";
import { L as LayoutDashboard } from "./layoutDashboard-126aa0e7.js";
import { router, Link } from "@inertiajs/react";
import { useState } from "react";
function AddTeacher({ subject }) {
  const [values, setValues] = useState({
    role: "teacher",
    username: "",
    name: "",
    subject_id: "",
    ttl: "",
    adress: "",
    phone: "",
    password: "",
    confirmPassword: ""
  });
  console.log(values);
  const [error, setError] = useState([]);
  function handleSubmit(e) {
    e.preventDefault();
    router.post("/teacher", values);
  }
  function handleChange(e) {
    setValues((val) => ({ ...val, [e.target.id]: e.target.value }));
  }
  router.on("error", (errors) => {
    setError(errors.detail.errors);
  });
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsx(LayoutDashboard, { setActiveLink: "Teacher", children: /* @__PURE__ */ jsxs("div", { className: "m-5", children: [
    /* @__PURE__ */ jsx("div", { className: "flex gap-2", children: /* @__PURE__ */ jsx(Link, { href: "/teacher", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1 ", children: [
      /* @__PURE__ */ jsx(
        "svg",
        {
          className: "fill-gray-500",
          height: "16",
          width: "14",
          viewBox: "0 0 448 512",
          children: /* @__PURE__ */ jsx("path", { d: "M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l160 160c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L109.2 288 416 288c17.7 0 32-14.3 32-32s-14.3-32-32-32l-306.7 0L214.6 118.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-160 160z" })
        }
      ),
      /* @__PURE__ */ jsx("p", { className: "text-gray-700", children: "Back" })
    ] }) }) }),
    /* @__PURE__ */ jsxs(Form, { title: "Input Student", onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-5 gap-2", children: [
        /* @__PURE__ */ jsx("div", { className: "col-span-2", children: /* @__PURE__ */ jsx(
          InputText,
          {
            label: "Username",
            id: "username",
            onChange: handleChange,
            value: values.username,
            error: error.username
          }
        ) }),
        /* @__PURE__ */ jsx("div", { className: "col-span-3", children: /* @__PURE__ */ jsx(
          InputText,
          {
            label: "Nama Lengkap",
            id: "name",
            onChange: handleChange,
            value: values.name,
            error: error.name
          }
        ) })
      ] }),
      /* @__PURE__ */ jsxs(
        InputSelect,
        {
          label: "Mata Pelajaran",
          id: "subject_id",
          onChange: handleChange,
          defaultValue: values.subject_id,
          error: error.grade,
          children: [
            /* @__PURE__ */ jsx("option", { value: "", children: "--Pilih--" }),
            subject.map((i) => /* @__PURE__ */ jsx("option", { value: i.id, children: i.subject }, i.id))
          ]
        }
      ),
      /* @__PURE__ */ jsx(
        InputText,
        {
          label: "T-T-L",
          id: "ttl",
          onChange: handleChange,
          value: values.ttl,
          error: error.ttl
        }
      ),
      /* @__PURE__ */ jsx(
        InputText,
        {
          label: "Alamat",
          id: "adress",
          onChange: handleChange,
          value: values.adress,
          error: error.adress
        }
      ),
      /* @__PURE__ */ jsx(
        InputText,
        {
          label: "Whatsapp",
          id: "phone",
          onChange: handleChange,
          value: values.phone,
          error: error.phone
        }
      ),
      /* @__PURE__ */ jsx(
        InputText,
        {
          label: "Kata Sandi",
          id: "password",
          onChange: handleChange,
          value: values.password,
          error: error.password
        }
      ),
      /* @__PURE__ */ jsx(
        InputText,
        {
          label: "Konfirmasi Kata Sandi",
          id: "confirmPassword",
          onChange: handleChange,
          value: values.confirmPassword,
          error: error.confirmPassword
        }
      ),
      /* @__PURE__ */ jsx("div", { className: "flex gap-2 mt-5", children: /* @__PURE__ */ jsx(
        ButtonSubmit,
        {
          bgcolor: "bg-green-500",
          hover: "hover:bg-green-600",
          children: "Submit"
        }
      ) })
    ] })
  ] }) }) });
}
export {
  AddTeacher as default
};

import { jsx, Fragment } from "react/jsx-runtime";
function Coba() {
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsx("div", { className: "overflow-x-auto bg-red-200 w-full h-40", children: /* @__PURE__ */ jsx("table", { className: "w-full bg-blue-200", children: /* @__PURE__ */ jsx("tbody", { children: /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx("td", { children: "hehe" }) }) }) }) }) });
}
export {
  Coba as default
};

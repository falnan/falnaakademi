import { jsx, Fragment } from "react/jsx-runtime";
import { L as LayoutDashboard } from "./layoutDashboard-126aa0e7.js";
import "@inertiajs/react";
import "react";
function DashboardAdmin() {
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsx(LayoutDashboard, { setActiveLink: "Dashboard", children: "hehe" }) });
}
export {
  DashboardAdmin as default
};

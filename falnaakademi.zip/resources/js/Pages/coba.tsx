export default function Coba() {
    return (
        <>
            <div className="overflow-x-auto bg-red-200 w-full h-40">
                <table className="w-full bg-blue-200">
                    <tbody>
                        <tr>
                            <td>hehe</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </>
    );
}

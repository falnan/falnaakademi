import ButtonSubmit from "@/components/button";
import Form from "@/components/form";
import LayoutDashboard from "@/components/layoutDashboard";
import { Link, router } from "@inertiajs/react";
import { useState } from "react";

export default function AddStudentRoom() {
    const [values, setValues] = useState([""]);
    const [error, setError]: any = useState("");
    function handleSubmit(e: any) {
        e.preventDefault();
        router.post("/student", { data: values });
    }
    router.on("error", (errors: any) => {
        setError(errors.detail.errors);
    });

    console.log(values);
    return (
        <>
            <LayoutDashboard setActiveLink="Room">
                <div className="m-5">
                    <div className="flex gap-2">
                        <Link href="/student">
                            <div className="flex items-center gap-1 ">
                                <svg
                                    className="fill-gray-500"
                                    height="16"
                                    width="14"
                                    viewBox="0 0 448 512"
                                >
                                    <path d="M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l160 160c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L109.2 288 416 288c17.7 0 32-14.3 32-32s-14.3-32-32-32l-306.7 0L214.6 118.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-160 160z" />
                                </svg>
                                <p className="text-gray-700">Back</p>
                            </div>
                        </Link>
                    </div>
                    {/* form */}
                    <Form title="Input Student" onSubmit={handleSubmit}>
                        {values.map((i: any, index) => (
                            <div key={index}>
                                <input
                                    type="text"
                                    className="rounded-md border-none shadow ring-1 ring-blue-300"
                                    onChange={(e: any) =>
                                        setValues((val: any) =>
                                            [...val].toSpliced(
                                                index,
                                                1,
                                                e.target.value
                                            )
                                        )
                                    }
                                />
                            </div>
                        ))}
                        <div className="flex gap-2 mt-5">
                            <ButtonSubmit
                                bgcolor="bg-green-500"
                                hover="hover:bg-green-600"
                            >
                                Submit
                            </ButtonSubmit>
                        </div>
                    </Form>
                </div>
            </LayoutDashboard>
        </>
    );
}

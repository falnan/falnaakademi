import LayoutDashboard from "@/components/layoutDashboard";

export default function DashboardAdmin() {
    return (
        <>
            <LayoutDashboard setActiveLink="Dashboard">hehe</LayoutDashboard>
        </>
    );
}

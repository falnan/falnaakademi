export type TLogin = {
    username: string;
    name: string;
    password: string;
};
